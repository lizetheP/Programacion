# 3. Convertir de grados Centígrados a grados Fahrenheit.
# Digite el número de grados Centígrados que desea convertir a grados Fahrenheit.
# F = C*(9/5)+32   (utiliza la fórmula para realizar la conversión)
# El resultado debe mostrar X grados Centígrados corresponde a X grados Fahrenheit.

print("Nombre del alumno, matrícula, carrera, semestre")
print("Captura el número de grados centígrados que desea convertir a grados Fahrenheit")
GradosC=float(input())
GradosF=float(GradosC*(9/5)+32)
print(GradosC," grados centígrados corresponde a ",GradosF," grados Fahrenheit")

      

